"""Refine the four outfit groups on the lightweight v11 avatar."""
import math
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector

root = Path(__file__).resolve().parents[1]
out = root / 'work/butler-detail-v12'
out.mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(root / 'work/butler-lite-v11/musan-butler-lite-v11.glb'))


def object_named(prefix):
    return next(o for o in bpy.context.scene.objects if o.type == 'MESH' and o.data.name.startswith(prefix))


def remove_meshes(*prefixes):
    for obj in list(bpy.context.scene.objects):
        if obj.type == 'MESH' and obj.data.name.startswith(prefixes):
            bpy.data.objects.remove(obj, do_unlink=True)


def surface(name, vertices, faces, material, thickness=0):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    mesh.materials.append(material)
    for poly in mesh.polygons:
        poly.use_smooth = True
    if thickness:
        obj.modifiers.new('Cloth edge thickness', 'SOLIDIFY').thickness = thickness
    return obj


def oval(name, position, scale, material):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, location=position)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(material)
    obj.scale = scale
    for poly in obj.data.polygons:
        poly.use_smooth = True
    return obj


def cord(name, positions, radius, material):
    data = bpy.data.curves.new(name, 'CURVE')
    data.dimensions = '3D'
    data.resolution_u = 7
    data.bevel_resolution = 2
    data.bevel_depth = radius
    lane = data.splines.new('BEZIER')
    lane.bezier_points.add(len(positions) - 1)
    for point, position in zip(lane.bezier_points, positions):
        point.co = position
        point.handle_left_type = point.handle_right_type = 'AUTO'
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    data.materials.append(material)
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.convert(target='MESH')


satin = bpy.data.materials['Black satin lapels and bow']
silver = bpy.data.materials['Pearl silver headset']
black = bpy.data.materials['Headset charcoal cushion']
white = bpy.data.materials['Ivory cotton']
vest = bpy.data.materials['Charcoal waistcoat']
body = object_named('meshes[0]')
remove_meshes('Silver rear headband', 'Headset microphone boom', 'Soft satin bow wing',
              'Folded white service towel', 'Towel stitched hem')
# Some v09 accessories use generic sphere mesh names. Match their material
# and location so the original eyes and coat hardware remain untouched.
for obj in list(bpy.context.scene.objects):
    if obj.type != 'MESH' or not obj.data.materials:
        continue
    material = obj.data.materials[0]
    center = sum((obj.matrix_world @ Vector(corner) for corner in obj.bound_box), Vector()) / 8
    if center.z > .66 and material in (silver, black):
        bpy.data.objects.remove(obj, do_unlink=True)
    elif material == satin and abs(center.x) < .022 and .55 < center.z < .60:
        bpy.data.objects.remove(obj, do_unlink=True)

# Seat the silver capsule at the fur surface. Its diagonal runs from the
# front and lower boom attachment toward the back and upper end.
body_inverse = body.matrix_world.inverted()
origin = body_inverse @ Vector((0, -.117, .791))
direction = (body_inverse.to_3x3() @ Vector((1, 0, 0))).normalized()
hit, point, _, _ = body.ray_cast(origin, direction)
assert hit, 'Expected headset contact on the side of the head'
x = (body.matrix_world @ point).x
ear = oval('Inset silver ear unit', (x + .002, -.117, .791), (.014, .030, .063), silver)
ear.rotation_euler.x = -.92
oval('Black ear unit port', (x + .015, -.111, .798), (.003, .0035, .0035), black)
cord('Integral silver microphone boom',
     [(x+.005,-.161,.754),(x-.016,-.201,.725),(.194,-.231,.702),(.156,-.253,.692)], .0027, silver)
tip = oval('Silver microphone tip', (.151,-.255,.692), (.011,.0045,.0045), silver)
tip.rotation_euler.z = .35

# Keep the black bow pinched through the centre, with broad wings and a
# soft rectangular wrap. All three parts remain separate meshes.
for side in (-1, 1):
    ring_count, segments = 12, 20
    vertices = []
    for ring in range(ring_count + 1):
        t = ring / ring_count
        end_rounding = 1 - .18 * max(0, (t - .89) / .11) ** 2
        for segment in range(segments):
            angle = segment * 2 * math.pi / segments
            z = math.sin(angle)
            crease = math.exp(-(z / .24)**2) * (1 - t)**2 * .004
            y = -.293 + (.008 + .003*t) * math.cos(angle) + crease
            vertices.append((side*(.011+.054*t), y, .578+z*(.011+.020*t)*end_rounding))
    faces = [(r*segments+i, r*segments+(i+1)%segments,
              (r+1)*segments+(i+1)%segments, (r+1)*segments+i)
             for r in range(ring_count) for i in range(segments)]
    faces += [tuple(reversed(range(segments))), tuple(ring_count*segments+i for i in range(segments))]
    if side < 0:
        faces = [face[::-1] for face in faces]
    surface('Pinched satin bow wing', vertices, faces, satin)
knot = oval('Wrapped satin knot', (0,-.300,.578), (.014,.012,.019), satin)
for vertex in knot.data.vertices:
    vertex.co = [math.copysign(abs(v)**.54, v) for v in vertex.co]

# Button placement follows the shirt panel so the placket reads through
# the opening between the bow and the waistcoat.
shirt = object_named('White shirt front')
for z in (.538, .502, .466):
    ok, p, _, _ = shirt.ray_cast(shirt.matrix_world.inverted() @ Vector((0,-1,z)),
                                 (shirt.matrix_world.inverted().to_3x3() @ Vector((0,1,0))).normalized())
    if ok:
        world = shirt.matrix_world @ p
        oval('Black shirt placket button', (world.x,world.y-.003,world.z), (.006,.0035,.006), black)

# A subtle woven repeating damask pattern, embedded as a small texture.
size = 256
v, u = np.mgrid[0:size, 0:size] * (2 * math.pi / size)
petals = np.cos(4*u + .9*np.sin(4*v)) * np.cos(4*v - .9*np.sin(4*u))
motif = np.maximum(petals, 0)**4
colour = np.array([.16,.155,.15]) + motif[...,None]*.075
image = bpy.data.images.new('Charcoal damask repeat', size, size, alpha=False)
image.pixels.foreach_set(np.concatenate((colour, np.ones((size,size,1))), axis=-1).astype('f4').ravel())
image.pack()
nodes = vest.node_tree.nodes
tex = nodes.new('ShaderNodeTexImage')
tex.image = image
vest.node_tree.links.new(tex.outputs['Color'], next(n for n in nodes if n.type == 'BSDF_PRINCIPLED').inputs['Base Color'])

# Fit each back button against the actual coat or tail at its position.
back_cloth = [o for o in bpy.context.scene.objects if o.type == 'MESH'
              and o.data.name.startswith(('Black tailcoat body', 'Long coat tail'))]
for obj in bpy.context.scene.objects:
    if obj.type != 'MESH' or not obj.data.materials or obj.data.materials[0].name != 'Brushed warm gold buttons':
        continue
    transform = obj.matrix_world.copy()
    x, y, z = transform.translation
    if y <= 0:
        continue
    contacts = []
    for cloth in back_cloth:
        inverse = cloth.matrix_world.inverted()
        ok, point, _, _ = cloth.ray_cast(inverse @ Vector((x,1,z)),
                                        (inverse.to_3x3() @ Vector((0,-1,0))).normalized())
        if ok:
            contacts.append((cloth.matrix_world @ point).y)
    if contacts:
        transform.translation.y = max(contacts) + .003
        obj.matrix_world = transform

# One continuous towel surface curves over the arm and drops in two layers.
path = [(-.104,.115),(-.102,.205),(-.101,.292),(-.113,.336),(-.135,.359),
        (-.161,.368),(-.187,.360),(-.208,.338),(-.220,.297),(-.225,.208),(-.225,.119)]
cols = 12
vertices = [(-.367 + (i/cols-.5)*.130, y+.003*math.cos(i/cols*math.pi*2), z)
            for y,z in path for i in range(cols+1)]
faces = [(r*(cols+1)+i,r*(cols+1)+i+1,(r+1)*(cols+1)+i+1,(r+1)*(cols+1)+i)
         for r in range(len(path)-1) for i in range(cols)]
towel = surface('White towel with two draped layers',vertices,faces,white,.0035)
towel.modifiers.new('Smooth the cloth fold', 'SUBSURF').levels = 2
for y,z in [(-.227,.132),(-.102,.128)]:
    cord('Towel double fold hem', [(-.426,y,z),(-.367,y-.002,z),(-.308,y,z)], .00085, white)
    # Use short individual strokes, grouped in one mesh to keep draw calls low.
    stitches, quads = [], []
    thread = white.copy()
    thread.name = 'Ivory towel hem thread'
    for i in range(28):
        x = -.423 + i*.0042
        k = len(stitches)
        stitches.extend(((x,y-.001,z+.003),(x+.0023,y-.001,z+.003),
                         (x+.0023,y-.001,z+.0038),(x,y-.001,z+.0038)))
        quads.append((k,k+1,k+2,k+3))
    surface('Towel hem stitch row', stitches, quads, thread)

bpy.ops.export_scene.gltf(filepath=str(out/'musan-butler-detail-v12.glb'),
                          export_format='GLB', export_apply=True,
                          export_vertex_color='ACTIVE', export_all_vertex_colors=False)
