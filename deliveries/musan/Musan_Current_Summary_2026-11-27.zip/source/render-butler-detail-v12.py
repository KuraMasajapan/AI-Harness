"""Review the actual exported GLB from the reference directions."""
import bpy
from pathlib import Path
from mathutils import Vector

root = Path(__file__).resolve().parents[1]
out = root / 'work/butler-detail-v12'
bpy.ops.wm.open_mainfile(filepath=str(root / 'work/avatar-base-v01/review/avatar-review.blend'))
for obj in list(bpy.context.scene.objects):
    if obj.type == 'MESH' and obj.name != 'Review ground':
        bpy.data.objects.remove(obj, do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(out / 'musan-butler-detail-v12.glb'))
scene = bpy.context.scene
scene.cycles.device = 'CPU'
scene.cycles.samples = 14
scene.cycles.use_denoising = True
scene.render.resolution_x = 520
scene.render.resolution_y = 620
scene.render.resolution_percentage = 100
cam = scene.camera
for name, position in [('front',(0,-3,.55)),('headset-side',(3,-.65,.59)),('back',(0,3,.58))]:
    target = Vector((0,0,.50))
    cam.location = position
    cam.rotation_euler = (target-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.ortho_scale = 1.22
    scene.render.filepath = str(out / (name + '.png'))
    bpy.ops.render.render(write_still=True)
