﻿むーさん・Museスペース 現在の成果まとめ
作成日 2026-11-27

最新版
models/musan-butler-detail-v12.glb
執事服、片耳銀色ヘッドセット、一体型マイク、蝶ネクタイ、ベスト柄、
白シャツの黒ボタン、白タオルを含む。モデルは約7.95 MB。

台所
models/kitchen-study.glb
キャラクターと部屋は別モデル。配置値は muse/scene-placement.json に記載。
Museへ渡す際は models 内のGLB2点と muse 内の配置JSON・依頼文を使用する。

確認画像
preview/front.png、side.png、back.png はv12の実GLBから描画した画像。
preview/kitchen-layout-v11.png は前段階v11の部屋配置確認用画像。

現在の状態
GLBは静止モデル。リグ・アニメーションは未実装。
v12のiPhone実機・Muse表示は未確認。
袖と燕尾の形状には硬さが残り、毛並みは参照画像より滑らか。
人間による参照画像との見比べと、Museでの表示確認が次工程。
Gate01はユーザー報告で完了済み。

再開用
progress/CHECKPOINT.md はこれまでの進捗記録。過去の未完了記述も含む。
source/ はv12の改修・レンダー用スクリプト。既存プロジェクトを前提とする。
このZIPは現在の成果の受け渡し用で、全制作履歴・全依存素材のバックアップではない。
manifest.json に同梱各ファイルのサイズとSHA-256を記録。
